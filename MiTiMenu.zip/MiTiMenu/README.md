# 🎨 MiTiMenu — iOS dylib Injection

Menu nổi đẹp hiển thị tên **MiTi** và các link, inject vào IPA của bạn.

---

## 📁 Cấu trúc thư mục

```
MiTiMenu/
├── MiTiMenu.m                  ← Source code menu
├── Makefile                    ← Build script
└── .github/
    └── workflows/
        └── build.yml           ← GitHub Actions (build tự động)
```

---

## 🚀 Cách dùng (chỉ cần điện thoại)

### Bước 1 — Tạo repo GitHub
1. Vào **github.com** → **New repository**
2. Tên repo: `MiTiMenu` (public hoặc private đều được)
3. **KHÔNG** tích "Add README" (để trống)

### Bước 2 — Upload file
Upload 3 file theo đúng đường dẫn:
```
MiTiMenu.m
Makefile
.github/workflows/build.yml
```
> Tạo folder `.github/workflows/` bằng cách gõ tên file là `.github/workflows/build.yml` khi upload

### Bước 3 — Chờ build
1. Vào tab **Actions** trên GitHub
2. Chờ job chạy xong (khoảng 3–5 phút) ✅
3. Click vào job → kéo xuống **Artifacts**
4. Download **MiTiMenu-dylib.zip** → giải nén ra **MiTiMenu.dylib**

### Bước 4 — Inject vào IPA
Dùng **Sideloadly** (Windows/Mac) hoặc **Esign** (iOS):

**Với Sideloadly (PC/Mac):**
1. Kéo IPA vào Sideloadly
2. Bật "Inject dylib/framework"
3. Thêm `MiTiMenu.dylib`
4. Sign và cài

**Với Esign (trên iPhone, không cần PC):**
1. Import IPA vào Esign
2. Chọn IPA → Inject → thêm dylib
3. Sign và cài

---

## ✏️ Thêm link nhóm sau

Mở `MiTiMenu.m`, tìm phần:
```objc
self.links = @[
    @{ @"icon": @"🎬", @"title": @"YouTube — MiTi",  @"url": @"https://www.youtube.com/@ymt139" },
    // Thêm link nhóm ở đây sau
];
```

Thêm dòng như sau:
```objc
@{ @"icon": @"💬", @"title": @"Nhóm Telegram", @"url": @"https://t.me/tennhom" },
@{ @"icon": @"📘", @"title": @"Facebook Group",  @"url": @"https://fb.com/groups/xxx" },
```

---

## 🎯 Tính năng menu

- ✅ Nút nổi **"M"** góc phải, kéo thả được
- ✅ Bấm mở menu card đẹp slide lên
- ✅ Nút **✕** góc trên phải để đóng
- ✅ Bấm vào link → mở trình duyệt
- ✅ Hiệu ứng animation mượt
- ✅ Dark theme gradient
- ✅ Hoạt động trên iOS 14+, không cần jailbreak
